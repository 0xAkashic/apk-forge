package com.example

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Settings Repository using App Context
        XReplyRepository.init(applicationContext)

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    "AIXReplyPro Settings",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = Color(0xFF15202B)
                            )
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF15202B))
                            .padding(innerPadding)
                    ) {
                        SettingsScreen()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Force state updates when user returns from system settings
    }
}

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Preferences & state collects
    val currentTweet = XReplyRepository.latestTweetText.collectAsState().value
    val isGenerating = XReplyRepository.isGenerating.collectAsState().value
    val lastResponse = XReplyRepository.generatedReply.collectAsState().value

    val savedGroqKey = XReplyRepository.groqApiKey.collectAsState().value
    val savedGeminiKey = XReplyRepository.geminiApiKey.collectAsState().value
    val selectedProvider = XReplyRepository.selectedProvider.collectAsState().value
    val replyStyle = XReplyRepository.replyStyle.collectAsState().value

    // Inputs
    var groqInput by remember(savedGroqKey) { mutableStateOf(savedGroqKey) }
    var geminiInput by remember(savedGeminiKey) { mutableStateOf(savedGeminiKey) }
    var showGroqKey by remember { mutableStateOf(false) }
    var showGeminiKey by remember { mutableStateOf(false) }

    // Floating Overlay check
    var isOverlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    // Accessibility check
    var isAccessibilityEnabled by remember {
        mutableStateOf(isAccessibilityServiceEnabled(context, XAccessibilityService::class.java))
    }

    // Refresh states on display
    LaunchedEffect(Unit) {
        isOverlayGranted = Settings.canDrawOverlays(context)
        isAccessibilityEnabled = isAccessibilityServiceEnabled(context, XAccessibilityService::class.java)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // --- SECTION 1: Service Status ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2732)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "System Requirements",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Overlay Permission Row
                StatusRow(
                    title = "Overlay Widget Permission",
                    subtitle = "Required to show the 🙈 floating reply button",
                    isOk = isOverlayGranted,
                    onConfigure = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }
                )

                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFF38444D))

                // Accessibility Permission Row
                StatusRow(
                    title = "Accessibility Detection",
                    subtitle = "Required to automatically read tweets on Twitter (X)",
                    isOk = isAccessibilityEnabled,
                    onConfigure = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    }
                )
            }
        }

        // --- SECTION 2: Launcher Controls ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2732)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Service Controls",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            if (!Settings.canDrawOverlays(context)) {
                                Toast.makeText(context, "Please grant Overlay Permission first!", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            val intent = Intent(context, FloatingService::class.java)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.startForegroundService(intent)
                            } else {
                                context.startService(intent)
                            }
                            Toast.makeText(context, "AI Reply overlay started! 🙈", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DA1F2))
                    ) {
                        Text("Start Overlay", color = Color.White)
                    }

                    Button(
                        onClick = {
                            val intent = Intent(context, FloatingService::class.java)
                            context.stopService(intent)
                            Toast.makeText(context, "Overlay dismissed.", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0245E))
                    ) {
                        Text("Stop Overlay", color = Color.White)
                    }
                }
            }
        }

        // --- SECTION 3: API Configurations ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2732)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "API Key Configurations",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Groq API Key Input
                OutlinedTextField(
                    value = groqInput,
                    onValueChange = { groqInput = it },
                    label = { Text("Groq API Key", color = Color(0xFF8899A6)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF1DA1F2),
                        unfocusedBorderColor = Color(0xFF38444D),
                        focusedLabelColor = Color(0xFF1DA1F2)
                    ),
                    visualTransformation = if (showGroqKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        TextButton(onClick = { showGroqKey = !showGroqKey }) {
                            Text(
                                text = if (showGroqKey) "Hide" else "Show",
                                color = Color(0xFF1DA1F2),
                                fontSize = 12.sp
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Gemini API Key Input
                OutlinedTextField(
                    value = geminiInput,
                    onValueChange = { geminiInput = it },
                    label = { Text("Gemini API Key", color = Color(0xFF8899A6)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF1DA1F2),
                        unfocusedBorderColor = Color(0xFF38444D),
                        focusedLabelColor = Color(0xFF1DA1F2)
                    ),
                    visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        TextButton(onClick = { showGeminiKey = !showGeminiKey }) {
                            Text(
                                text = if (showGeminiKey) "Hide" else "Show",
                                color = Color(0xFF1DA1F2),
                                fontSize = 12.sp
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        XReplyRepository.saveGroqApiKey(context, groqInput)
                        XReplyRepository.saveGeminiApiKey(context, geminiInput)
                        Toast.makeText(context, "API Keys Saved Successfully! 📁", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DA1F2))
                ) {
                    Text("Save Keys", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        // --- SECTION 4: AI Settings ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2732)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "AI Model Options",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Selected Provider Toggle
                Text("Select Provider:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        RadioButton(
                            selected = selectedProvider == "gemini",
                            onClick = { XReplyRepository.saveSelectedProvider(context, "gemini") },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = Color(0xFF1DA1F2),
                                unselectedColor = Color(0xFF8899A6)
                            )
                        )
                        Text("Google Gemini", color = Color.White, fontSize = 14.sp)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        RadioButton(
                            selected = selectedProvider == "groq",
                            onClick = { XReplyRepository.saveSelectedProvider(context, "groq") },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = Color(0xFF1DA1F2),
                                unselectedColor = Color(0xFF8899A6)
                            )
                        )
                        Text("Groq (Llama-3)", color = Color.White, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Selected Style Selection
                Text("Reply Tone Style:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))

                val styles = listOf("Funny", "Snarky", "Professional", "Supportive")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    styles.forEach { style ->
                        val isSelected = replyStyle == style
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF1DA1F2) else Color(0xFF15181C))
                                .clickable { XReplyRepository.saveReplyStyle(context, style) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = style,
                                color = if (isSelected) Color.White else Color(0xFF8899A6),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- SECTION 5: Testing Playground ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2732)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Live Sandbox / Playground",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Tweet Input
                var sandboxInput by remember { mutableStateOf("") }
                OutlinedTextField(
                    value = sandboxInput,
                    onValueChange = { sandboxInput = it },
                    label = { Text("Simulate tweet text to reply", color = Color(0xFF8899A6)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF1DA1F2),
                        unfocusedBorderColor = Color(0xFF38444D),
                        focusedLabelColor = Color(0xFF1DA1F2)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (sandboxInput.isBlank()) {
                            Toast.makeText(context, "Please enter some simulated tweet first!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        XReplyRepository.setLatestTweetText(sandboxInput)
                        XReplyRepository.setIsGenerating(true)
                        XReplyRepository.setGeneratedReply("Generating...")

                        CoroutineScope(Dispatchers.Main).launch {
                            val result = AiApiClient.generateReply(
                                tweetText = sandboxInput,
                                groqKey = groqInput,
                                geminiKey = geminiInput,
                                provider = selectedProvider,
                                style = replyStyle
                            )
                            XReplyRepository.setIsGenerating(false)
                            result.onSuccess {
                                XReplyRepository.setGeneratedReply(it)
                            }.onFailure {
                                XReplyRepository.setGeneratedReply("Failed: ${it.message}")
                            }
                        }
                    },
                    enabled = !isGenerating,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF19CF86))
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                    } else {
                        Text("Simulate Generation", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                if (lastResponse.isNotBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF15181C))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text("Last Result:", color = Color(0xFF8899A6), fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(lastResponse, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusRow(
    title: String,
    subtitle: String,
    isOk: Boolean,
    onConfigure: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isOk) Icons.Default.Check else Icons.Default.Close,
                    contentDescription = null,
                    tint = if (isOk) Color(0xFF19CF86) else Color(0xFFE0245E),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White
                )
            }
            Text(
                text = subtitle,
                color = Color(0xFF8899A6),
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 22.dp)
            )
        }

        Button(
            onClick = onConfigure,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isOk) Color(0xFF253341) else Color(0xFF1DA1F2)
            ),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.height(34.dp)
        ) {
            Text(
                text = if (isOk) "Configure" else "Enable",
                fontSize = 12.sp,
                color = Color.White
            )
        }
    }
}

fun isAccessibilityServiceEnabled(context: Context, service: Class<out AccessibilityService>): Boolean {
    val expectedComponentName = ComponentName(context, service)
    val enabledServicesSetting = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val colonSplitter = TextUtils.SimpleStringSplitter(':')
    colonSplitter.setString(enabledServicesSetting)
    while (colonSplitter.hasNext()) {
        val componentNameString = colonSplitter.next()
        val enabledService = ComponentName.unflattenFromString(componentNameString)
        if (enabledService != null && enabledService == expectedComponentName) {
            return true
        }
    }
    return false
}
