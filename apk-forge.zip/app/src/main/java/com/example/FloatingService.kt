package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import android.app.Service
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class FloatingService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null

    // Lifecycle implementation for Compose View tree
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(1, createNotification())

        showFloatingButton()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "floating_service_channel",
                "AI Reply Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, "floating_service_channel")
            .setContentTitle("AIXReplyPro Active")
            .setContentText("Overlay button is running. Open X (Twitter) to generate replies.")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun showFloatingButton() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 500
        }

        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingService)
            setViewTreeViewModelStoreOwner(this@FloatingService)
            setViewTreeSavedStateRegistryOwner(this@FloatingService)

            setContent {
                FloatingWidget(
                    onDrag = { dx, dy ->
                        params?.let {
                            it.x += dx.roundToInt()
                            it.y += dy.roundToInt()
                            windowManager.updateViewLayout(this, it)
                        }
                    },
                    onGenerateClick = {
                        generateReplyForLatestTweet()
                    }
                )
            }
        }

        windowManager.addView(composeView, params)
    }

    private fun generateReplyForLatestTweet() {
        val text = XReplyRepository.latestTweetText.value
        if (text.isBlank()) {
            Toast.makeText(this, "Open Twitter & select a tweet first! 🙈", Toast.LENGTH_LONG).show()
            return
        }

        XReplyRepository.setIsGenerating(true)
        XReplyRepository.setGeneratedReply("Generating...")

        val groqKey = XReplyRepository.groqApiKey.value
        val geminiKey = XReplyRepository.geminiApiKey.value
        val provider = XReplyRepository.selectedProvider.value
        val style = XReplyRepository.replyStyle.value

        CoroutineScope(Dispatchers.Main).launch {
            val result = AiApiClient.generateReply(
                tweetText = text,
                groqKey = groqKey,
                geminiKey = geminiKey,
                provider = provider,
                style = style
            )
            XReplyRepository.setIsGenerating(false)
            result.onSuccess { reply ->
                XReplyRepository.setGeneratedReply(reply)
                copyToClipboard(reply)
                Toast.makeText(this@FloatingService, "Reply Copied! 📋", Toast.LENGTH_SHORT).show()
            }.onFailure { error ->
                XReplyRepository.setGeneratedReply("Error: ${error.message}")
                Toast.makeText(this@FloatingService, "Generation failed: ${error.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("AI Tweet Reply", text)
        clipboard.setPrimaryClip(clip)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        composeView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

@Composable
fun FloatingWidget(
    onDrag: (Float, Float) -> Unit,
    onGenerateClick: () -> Unit
) {
    val latestTweet = XReplyRepository.latestTweetText.collectAsState().value
    val isGenerating = XReplyRepository.isGenerating.collectAsState().value
    val generatedReply = XReplyRepository.generatedReply.collectAsState().value
    val provider = XReplyRepository.selectedProvider.collectAsState().value
    val replyStyle = XReplyRepository.replyStyle.collectAsState().value

    var isExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            }
            .wrapContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Floating circular button with customized states
        Box(
            modifier = Modifier
                .size(54.dp)
                .shadow(8.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    if (isGenerating) Color(0xFFFF9800) else Color(0xFF1DA1F2)
                )
                .clickable {
                    isExpanded = !isExpanded
                    if (isExpanded && latestTweet.isNotBlank() && !isGenerating && generatedReply.isBlank()) {
                        onGenerateClick()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            if (isGenerating) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = "🙈",
                    fontSize = 24.sp
                )
            }
        }

        // Expanded response panel
        AnimatedVisibility(
            visible = isExpanded,
            enter = slideInHorizontally() + fadeIn(),
            exit = slideOutHorizontally() + fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .padding(start = 8.dp)
                    .width(260.dp)
                    .shadow(12.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2732))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "X AI Reply Pro",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Using: ${provider.uppercase()} ($replyStyle)",
                                color = Color(0xFF8899A6),
                                fontSize = 10.sp
                            )
                        }
                        IconButton(
                            onClick = { isExpanded = false },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF15181C))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = if (latestTweet.isNotBlank()) "Tweet: \"$latestTweet\"" else "No tweet read yet.",
                            color = Color(0xFF8899A6),
                            fontSize = 11.sp,
                            maxLines = 2
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (generatedReply.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF253341))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = generatedReply,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.W500
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = onGenerateClick,
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Regenerate",
                                    tint = Color(0xFF1DA1F2),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Retry", color = Color(0xFF1DA1F2), fontSize = 11.sp)
                            }
                        }
                    } else {
                        Button(
                            onClick = onGenerateClick,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DA1F2))
                        ) {
                            Text("Generate Reply", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
