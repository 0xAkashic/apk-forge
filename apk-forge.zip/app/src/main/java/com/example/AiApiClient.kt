package com.example

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object AiApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
    private const val GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    suspend fun generateReply(
        tweetText: String,
        groqKey: String,
        geminiKey: String,
        provider: String, // "groq" or "gemini"
        style: String // "Funny", "Professional", "Snarky", "Supportive"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (provider == "groq") {
                if (groqKey.isBlank()) {
                    return@withContext Result.failure(Exception("Groq API Key is not set"))
                }
                val systemPrompt = "You are an assistant generating short replies to Twitter (X) tweets. Compose a short, natural reply of exactly 10 to 15 words. Reply style: $style."
                val userPrompt = "Tweet text: \"$tweetText\"\nGenerate reply:"

                val json = JSONObject().apply {
                    put("model", "llama-3.3-70b-versatile")
                    put("messages", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "system")
                            put("content", systemPrompt)
                        })
                        put(JSONObject().apply {
                            put("role", "user")
                            put("content", userPrompt)
                        })
                    })
                }

                val request = Request.Builder()
                    .url(GROQ_URL)
                    .addHeader("Authorization", "Bearer $groqKey")
                    .addHeader("Content-Type", "application/json")
                    .post(json.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(Exception("Groq API error: Code ${response.code} ${response.message}"))
                    }
                    val bodyString = response.body?.string() ?: return@withContext Result.failure(Exception("No response body"))
                    val jsonResponse = JSONObject(bodyString)
                    val reply = jsonResponse.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                    Result.success(reply.trim().removeSurrounding("\""))
                }
            } else {
                if (geminiKey.isBlank()) {
                    return@withContext Result.failure(Exception("Gemini API Key is not set"))
                }
                val promptText = "You are generating a short reply to Twitter (X) tweets. Compose a short, natural reply of exactly 10 to 15 words. Reply style: $style.\n\nTweet: \"$tweetText\"\n\nreply:"

                val part = JSONObject().apply {
                    put("text", promptText)
                }
                val content = JSONObject().apply {
                    put("parts", JSONArray().apply { put(part) })
                }
                val json = JSONObject().apply {
                    put("contents", JSONArray().apply { put(content) })
                }

                val urlWithKey = "$GEMINI_URL?key=$geminiKey"
                val request = Request.Builder()
                    .url(urlWithKey)
                    .addHeader("Content-Type", "application/json")
                    .post(json.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(Exception("Gemini API error: Code ${response.code} ${response.message}"))
                    }
                    val bodyString = response.body?.string() ?: return@withContext Result.failure(Exception("No response body"))
                    val jsonResponse = JSONObject(bodyString)
                    val reply = jsonResponse.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    Result.success(reply.trim().removeSurrounding("\""))
                }
            }
        } catch (e: Exception) {
            Log.e("AiApiClient", "Failed to generate reply", e)
            Result.failure(e)
        }
    }
}
