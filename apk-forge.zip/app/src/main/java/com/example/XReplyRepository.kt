package com.example

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object XReplyRepository {
    private const val PREFS_NAME = "XReplyPrefs"
    private const val KEY_GROQ_API_KEY = "groq_api_key"
    private const val KEY_GEMINI_API_KEY = "gemini_api_key"
    private const val KEY_PROVIDER = "provider"
    private const val KEY_STYLE = "style"

    private val _latestTweetText = MutableStateFlow("")
    val latestTweetText: StateFlow<String> = _latestTweetText

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    private val _generatedReply = MutableStateFlow("")
    val generatedReply: StateFlow<String> = _generatedReply

    private val _groqApiKey = MutableStateFlow("")
    val groqApiKey: StateFlow<String> = _groqApiKey

    private val _geminiApiKey = MutableStateFlow("")
    val geminiApiKey: StateFlow<String> = _geminiApiKey

    private val _selectedProvider = MutableStateFlow("gemini") // "groq" or "gemini"
    val selectedProvider: StateFlow<String> = _selectedProvider

    private val _replyStyle = MutableStateFlow("Funny") // "Funny", "Professional", "Snarky", "Supportive"
    val replyStyle: StateFlow<String> = _replyStyle

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _groqApiKey.value = prefs.getString(KEY_GROQ_API_KEY, "") ?: ""
        _geminiApiKey.value = prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
        _selectedProvider.value = prefs.getString(KEY_PROVIDER, "gemini") ?: "gemini"
        _replyStyle.value = prefs.getString(KEY_STYLE, "Funny") ?: "Funny"
    }

    fun setLatestTweetText(text: String) {
        _latestTweetText.value = text
    }

    fun setIsGenerating(generating: Boolean) {
        _isGenerating.value = generating
    }

    fun setGeneratedReply(reply: String) {
        _generatedReply.value = reply
    }

    fun saveGroqApiKey(context: Context, key: String) {
        _groqApiKey.value = key
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_GROQ_API_KEY, key)
            .apply()
    }

    fun saveGeminiApiKey(context: Context, key: String) {
        _geminiApiKey.value = key
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_GEMINI_API_KEY, key)
            .apply()
    }

    fun saveSelectedProvider(context: Context, provider: String) {
        _selectedProvider.value = provider
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PROVIDER, provider)
            .apply()
    }

    fun saveReplyStyle(context: Context, style: String) {
        _replyStyle.value = style
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_STYLE, style)
            .apply()
    }
}
