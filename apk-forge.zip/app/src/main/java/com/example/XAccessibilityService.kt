package com.example

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class XAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: ""
        if (packageName == "com.twitter.android") {
            try {
                val rootNode = rootInActiveWindow ?: return
                val tweetText = findTweetText(rootNode)
                if (tweetText != null && tweetText.isNotBlank()) {
                    if (XReplyRepository.latestTweetText.value != tweetText) {
                        Log.d("XAccessibility", "Found tweet text: $tweetText")
                        XReplyRepository.setLatestTweetText(tweetText)
                    }
                }
                rootNode.recycle()
            } catch (e: Exception) {
                Log.e("XAccessibility", "Error reading window", e)
            }
        }
    }

    private fun findTweetText(node: AccessibilityNodeInfo?): String? {
        if (node == null) return null

        // Try searching specifically by Twitter's tweet text id
        val tweetTextId = "com.twitter.android:id/tweet_text"
        val nodesById = node.findAccessibilityNodeInfosByViewId(tweetTextId)
        if (nodesById != null && nodesById.isNotEmpty()) {
            for (n in nodesById) {
                val text = n.text?.toString()
                if (!text.isNullOrBlank()) {
                    return text
                }
            }
        }

        // Fallback: search recursively for text containing certain patterns or just common elements
        return traverseNodeForTweetText(node)
    }

    private fun traverseNodeForTweetText(node: AccessibilityNodeInfo): String? {
        val viewId = node.viewIdResourceName ?: ""
        if (viewId.endsWith("tweet_text")) {
            val text = node.text?.toString()
            if (!text.isNullOrBlank()) return text
        }

        // Check children
        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i) ?: continue
            val result = traverseNodeForTweetText(child)
            child.recycle()
            if (result != null) return result
        }
        return null
    }

    override fun onInterrupt() {
        Log.d("XAccessibility", "Service Interrupted")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d("XAccessibility", "Service Connected")
    }
}
